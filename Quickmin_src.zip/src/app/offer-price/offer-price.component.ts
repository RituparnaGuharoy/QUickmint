import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offer-price',
  templateUrl: './offer-price.component.html',
  styleUrls: ['./offer-price.component.css']
})
export class OfferPriceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
