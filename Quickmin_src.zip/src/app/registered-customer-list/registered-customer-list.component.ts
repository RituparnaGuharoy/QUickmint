import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registered-customer-list',
  templateUrl: './registered-customer-list.component.html',
  styleUrls: ['./registered-customer-list.component.css']
})
export class RegisteredCustomerListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
