import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provider-my-account',
  templateUrl: './provider-my-account.component.html',
  styleUrls: ['./provider-my-account.component.css']
})
export class ProviderMyAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
