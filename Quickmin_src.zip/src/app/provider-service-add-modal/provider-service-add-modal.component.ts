import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provider-service-add-modal',
  templateUrl: './provider-service-add-modal.component.html',
  styleUrls: ['./provider-service-add-modal.component.css']
})
export class ProviderServiceAddModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
