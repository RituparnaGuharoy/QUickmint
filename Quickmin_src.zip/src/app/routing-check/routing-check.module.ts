import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoutingCheckRoutingModule } from './routing-check-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RoutingCheckRoutingModule
  ]
})
export class RoutingCheckModule { }
