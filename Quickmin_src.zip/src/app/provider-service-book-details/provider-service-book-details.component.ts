import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provider-service-book-details',
  templateUrl: './provider-service-book-details.component.html',
  styleUrls: ['./provider-service-book-details.component.css']
})
export class ProviderServiceBookDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
