import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-book-details',
  templateUrl: './service-book-details.component.html',
  styleUrls: ['./service-book-details.component.css']
})
export class ServiceBookDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
