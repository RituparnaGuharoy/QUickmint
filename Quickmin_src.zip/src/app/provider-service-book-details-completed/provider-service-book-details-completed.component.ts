import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provider-service-book-details-completed',
  templateUrl: './provider-service-book-details-completed.component.html',
  styleUrls: ['./provider-service-book-details-completed.component.css']
})
export class ProviderServiceBookDetailsCompletedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
