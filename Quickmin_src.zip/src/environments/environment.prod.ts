export const environment = {
  production: true,
  // api: "http://localhost:5005/"
  api: "https://nodeserver.mydevfactory.com:4290/"
};
